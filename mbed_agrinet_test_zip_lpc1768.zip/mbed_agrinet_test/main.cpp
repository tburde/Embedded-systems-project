#include "mbed.h"
#include "parser.h"

char msg[128] = "UUID123 UTCS123 \r\n";

int main()
{
#ifdef DEBUG
    usb.baud(9600);
    usb.attach(&receive, Serial::RxIrq);
#else
    xbee.baud(9600);
    xbee.attach(&receive, Serial::RxIrq);
#endif
#ifdef Display
    lcd.cls();
    lcd.locate(0,3);
#ifdef BaseStation
    lcd.printf("AgriNet Base Station");
#endif
#ifdef SensorNode
    lcd.printf("AgriNet Sensor Node");
#endif
    wait(2);
    lcd.cls();
#endif

    while(1) {
    
        transmit(msg);
        wait(2);
        
    }
}

